import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const data = await prisma.bukti.findMany({ orderBy: { createdAt: "asc" } });
  return NextResponse.json(data);
}

export async function POST(req: Request) {
  const body = await req.json();
  try {
    const last = await prisma.bukti.findMany({ orderBy: { code: "desc" }, take: 1 });
    const nextNo = last.length ? Number(last[0].code.split("-")[1]) + 1 : 1;
    const code = `BKT-${String(nextNo).padStart(3, "0")}`;
    const created = await prisma.bukti.create({ data: { ...body, code } });
    return NextResponse.json(created, { status: 201 });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 400 });
  }
}
