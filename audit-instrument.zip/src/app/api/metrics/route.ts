import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { addDays, isBefore } from "date-fns";

export async function GET() {
  const [bukti, permintaan] = await Promise.all([
    prisma.bukti.findMany(),
    prisma.permintaan.findMany()
  ]);

  const valid = bukti.filter(b => b.validitas === "VALID").length;
  const perbaikan = bukti.filter(b => b.validitas === "PERBAIKAN").length;

  const terpenuhi = permintaan.filter(p => p.status === "TERPENUHI").length;
  const belum = permintaan.filter(p => p.status === "BELUM").length;

  const pemenuhanPct = Math.round((terpenuhi / Math.max(permintaan.length, 1)) * 100);

  const critical = permintaan.filter(p => p.tenggat && isBefore(p.tenggat, new Date()) && p.status !== "TERPENUHI").length;

  return NextResponse.json({
    totalBukti: bukti.length,
    totalPermintaan: permintaan.length,
    buktiStatus: { valid, perbaikan },
    permintaanStatus: { terpenuhi, belum },
    pemenuhanPct,
    critical
  });
}
