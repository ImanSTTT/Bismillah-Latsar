import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const data = await prisma.permintaan.findMany({ include: { bukti: true }, orderBy: { createdAt: "asc" } });
  return NextResponse.json(data);
}

export async function POST(req: Request) {
  const body = await req.json();
  try {
    const last = await prisma.permintaan.findMany({ orderBy: { code: "desc" }, take: 1 });
    const nextNo = last.length ? Number(last[0].code.split("-")[1]) + 1 : 1;
    const code = `PRM-${String(nextNo).padStart(3, "0")}`;
    const buktiConnect = (body.buktiIds || []).map((id:string)=>({ id }));
    const created = await prisma.permintaan.create({
      data: {
        code,
        deskripsi: body.deskripsi,
        tenggat: body.tenggat ? new Date(body.tenggat) : null,
        waktuText: body.waktuText,
        pic: body.pic,
        status: body.status,
        tglPemenuhan: body.tglPemenuhan ? new Date(body.tglPemenuhan) : null,
        bukti: { connect: buktiConnect }
      },
      include: { bukti: true }
    });
    // back-link bukti.permintaanId (optional)
    if (buktiConnect.length) {
      await prisma.bukti.updateMany({
        where: { id: { in: body.buktiIds } },
        data: { permintaanId: created.id }
      });
    }
    return NextResponse.json(created, { status: 201 });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 400 });
  }
}
