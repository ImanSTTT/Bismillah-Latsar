import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(_: Request, { params }: { params: { id: string } }) {
  const item = await prisma.permintaan.findUnique({ where: { id: params.id }, include: { bukti: true } });
  return NextResponse.json(item);
}

export async function PUT(req: Request, { params }: { params: { id: string } }) {
  const body = await req.json();
  try {
    const updated = await prisma.permintaan.update({
      where: { id: params.id },
      data: {
        deskripsi: body.deskripsi,
        tenggat: body.tenggat ? new Date(body.tenggat) : null,
        waktuText: body.waktuText,
        pic: body.pic,
        status: body.status,
        tglPemenuhan: body.tglPemenuhan ? new Date(body.tglPemenuhan) : null
      }
    });
    return NextResponse.json(updated);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 400 });
  }
}

export async function DELETE(_: Request, { params }: { params: { id: string } }) {
  try {
    await prisma.permintaan.delete({ where: { id: params.id } });
    return NextResponse.json({ ok: true });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 400 });
  }
}
