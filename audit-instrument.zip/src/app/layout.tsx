import "./globals.css";
import Link from "next/link";

export const metadata = {
  title: process.env.NEXT_PUBLIC_APP_NAME || "Instrument Bank Bukti & Permintaan Audit"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="id">
      <body className="min-h-screen">
        <div className="border-b border-white/5 bg-panel">
          <div className="container flex h-14 items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="size-8 rounded-lg bg-brand/30 grid place-items-center">🧾</div>
              <div className="text-sm">
                <div className="font-semibold">Instrument Bank Bukti & Permintaan Audit</div>
                <div className="text-xs text-muted">Kelola bank bukti, permintaan bukti, dan pantau persentase pemenuhan.</div>
              </div>
            </div>
            <div className="hidden md:flex items-center gap-3">
              <input placeholder="🔎 / untuk cari cepat..." className="input w-72" />
              <button className="btn-ghost">⬆️ Import</button>
              <button className="btn-ghost">⬇️ Export</button>
              <button className="btn-ghost">⚙︎</button>
            </div>
          </div>
        </div>
        <div className="container grid grid-cols-1 gap-6 py-6">
          <nav className="flex gap-3">
            <Link href="/" className="btn-ghost">📊 Dashboard</Link>
            <Link href="/permintaan" className="btn-ghost">📝 Permintaan</Link>
            <Link href="/bukti" className="btn-ghost">🗄️ Bank Bukti</Link>
          </nav>
          {children}
          <footer className="text-center text-xs text-muted py-6">© {new Date().getFullYear()} – Aplikasi Audit</footer>
        </div>
      </body>
    </html>
  );
}
