import { prisma } from "@/lib/prisma";
import Link from "next/link";
import BuktiForm from "@/components/BuktiForm";
import { ValiditasBadge } from "@/components/StatusBadge";
import { fmtDate } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function BankBukti() {
  const bukti = await prisma.bukti.findMany({ orderBy: { code: "asc" } });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Bank Bukti</h1>
          <p className="text-sm text-muted">Kelola database bukti audit dan dokumentasi</p>
        </div>
        <a href="#form-bukti" className="btn">+ Tambah Bukti</a>
      </div>

      <div className="card overflow-hidden">
        <table className="table">
          <thead>
            <tr>
              <th className="w-28">ID</th>
              <th>Kategori</th>
              <th>Deskripsi</th>
              <th>Link</th>
              <th>Unit</th>
              <th>PIC</th>
              <th>Tgl Diterima</th>
              <th>Validitas</th>
              <th>PRM Terkait</th>
            </tr>
          </thead>
          <tbody>
            {bukti.map((b:any)=>(
              <tr key={b.id}>
                <td className="font-mono">{b.code}</td>
                <td>{b.kategori}</td>
                <td>{b.deskripsi}</td>
                <td>{b.link ? <a href={b.link} className="text-brand underline" target="_blank">Buka</a> : "-"}</td>
                <td>{b.unit || "-"}</td>
                <td>{b.pic || "-"}</td>
                <td>{fmtDate(b.tglDiterima)}</td>
                <td><ValiditasBadge v={b.validitas} /></td>
                <td>{b.permintaanId ? <Link className="text-brand underline" href={"/permintaan"}>{b.permintaanId}</Link> : "-"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div id="form-bukti">
        <BuktiForm onCreated={() => location.reload()} />
      </div>
    </div>
  );
}
