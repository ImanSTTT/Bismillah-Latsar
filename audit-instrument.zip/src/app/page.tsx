import { prisma } from "@/lib/prisma";
import { ValiditasBadge, PermintaanBadge } from "@/components/StatusBadge";
import { formatDistanceToNow } from "date-fns";
import { id as localeId } from "date-fns/locale";
import Link from "next/link";

function Bar({ value }:{ value:number }) {
  return <div className="progress"><span style={{ width: `${value}%` }} /></div>;
}

export default async function Dashboard() {
  const [bukti, permintaan] = await Promise.all([
    prisma.bukti.findMany({ orderBy: { createdAt: "asc" } }),
    prisma.permintaan.findMany({ include: { bukti: true }, orderBy: { createdAt: "asc" } })
  ]);

  const buktiValid = bukti.filter(b=>b.validitas==="VALID").length;
  const buktiPerbaikan = bukti.filter(b=>b.validitas==="PERBAIKAN").length;

  const prmTerpenuhi = permintaan.filter(p=>p.status==="TERPENUHI").length;
  const prmBelum = permintaan.length - prmTerpenuhi;
  const pemenuhanPct = Math.round((prmTerpenuhi / Math.max(permintaan.length,1)) * 100);
  const critical = permintaan.filter(p => p.tenggat && p.status !== "TERPENUHI" && p.tenggat < new Date()).length;

  const aktivitas = [
    { d: "Kebijakan keamanan informasi", pic:"Rina", status:"Terpenuhi", date: new Date(Date.now()-26*86400000) },
    { d: "Prosedur backup", pic:"Andi", status:"Terpenuhi", date: new Date(Date.now()-23*86400000) },
    { d: "Laporan keamanan bulanan", pic:"Budi", status:"Belum", date: new Date(Date.now()-18*86400000) },
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Dashboard</h1>
      <p className="text-sm text-muted">Ringkasan status bank bukti dan permintaan audit</p>

      <div className="grid md:grid-cols-4 gap-4">
        <div className="card p-4 space-y-2">
          <div className="text-xs text-muted">Total Bank Bukti</div>
          <div className="text-3xl font-bold">{bukti.length}</div>
          <div className="text-xs text-muted">{buktiValid} valid, {buktiPerbaikan} perlu perbaikan</div>
        </div>
        <div className="card p-4 space-y-2">
          <div className="text-xs text-muted">Total Permintaan</div>
          <div className="text-3xl font-bold">{permintaan.length}</div>
          <div className="text-xs text-muted">{prmTerpenuhi} terpenuhi, {prmBelum} belum</div>
        </div>
        <div className="card p-4 space-y-2">
          <div className="text-xs text-muted">Persentase Pemenuhan</div>
          <div className="text-xl font-bold">{pemenuhanPct}%</div>
          <Bar value={pemenuhanPct} />
        </div>
        <div className="card p-4 space-y-2">
          <div className="text-xs text-muted">Status Kritis</div>
          <div className="text-3xl font-bold">{critical}</div>
          <div className="text-xs text-muted">{critical>0?"Memerlukan perhatian segera":"Tidak ada yang kritis"}</div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="card p-4 space-y-3">
          <div className="font-semibold">Status Bank Bukti</div>
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2"><span className="size-2 rounded-full bg-green-400"></span> Valid</div>
            <div>{buktiValid} • {Math.round((buktiValid/Math.max(bukti.length,1))*100)}%</div>
          </div>
          <Bar value={Math.round((buktiValid/Math.max(bukti.length,1))*100)} />
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2"><span className="size-2 rounded-full bg-yellow-400"></span> Perlu Perbaikan</div>
            <div>{buktiPerbaikan} • {Math.round((buktiPerbaikan/Math.max(bukti.length,1))*100)}%</div>
          </div>
          <Bar value={Math.round((buktiPerbaikan/Math.max(bukti.length,1))*100)} />
        </div>
        <div className="card p-4 space-y-3">
          <div className="font-semibold">Status Permintaan</div>
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2"><span className="size-2 rounded-full bg-green-400"></span> Terpenuhi</div>
            <div>{prmTerpenuhi} • {Math.round((prmTerpenuhi/Math.max(permintaan.length,1))*100)}%</div>
          </div>
          <Bar value={Math.round((prmTerpenuhi/Math.max(permintaan.length,1))*100)} />
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2"><span className="size-2 rounded-full bg-red-400"></span> Belum Terpenuhi</div>
            <div>{prmBelum} • {Math.round((prmBelum/Math.max(permintaan.length,1))*100)}%</div>
          </div>
          <Bar value={Math.round((prmBelum/Math.max(permintaan.length,1))*100)} />
        </div>
      </div>

      <div className="card p-4">
        <div className="font-semibold mb-3">Aktivitas Terbaru</div>
        <div className="divide-y divide-white/5">
          {aktivitas.map((a, i)=> (
            <div key={i} className="py-3 flex items-center justify-between">
              <div>
                <div className="text-sm">{a.d}</div>
                <div className="text-xs text-muted">PIC: {a.pic}</div>
              </div>
              <div className="flex items-center gap-3">
                <span className={a.status==="Terpenuhi"?"badge-green":"badge-red"}>{a.status}</span>
                <div className="text-xs text-muted">{formatDistanceToNow(a.date, { addSuffix:true, locale: localeId })}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
