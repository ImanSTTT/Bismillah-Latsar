import { format } from "date-fns";
export const cn = (...args: any[]) => args.filter(Boolean).join(" ");
export const fmtDate = (d?: Date | null) => (d ? format(d, "yyyy-MM-dd") : "-");
export const fmtDateShort = (d?: Date | null) => (d ? format(d, "dd-MM-yy") : "-");
export const pct = (a: number, b: number) => (b === 0 ? 0 : Math.round((a / b) * 100));
export const plural = (n:number, a:string, b?:string)=> (n===1?a:(b or f"{a}s"));
