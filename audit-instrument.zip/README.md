# Instrument Bank Bukti & Permintaan Audit

Aplikasi full-stack **Next.js 14 + Prisma + PostgreSQL** untuk mengelola **bank bukti** dan **permintaan bukti audit** dengan dashboard seperti pada screenshot.

## Fitur Utama
- Dashboard ringkasan (total bukti, total permintaan, % pemenuhan, status kritis)
- Modul **Bank Bukti** (CRUD via API) dengan kategori, validitas, PIC, dll
- Modul **Permintaan** (CRUD via API) dengan relasi ke banyak Bukti
- Dark UI modern dengan Tailwind (mirip screenshot)
- Seed data agar bisa langsung dicoba
- Siap deploy ke Vercel/Render/Railway/any hosting yang support Node + Postgres
- Export/Import tombol dummy (bisa Anda lengkapi)

## Menjalankan Lokal
1. Clone / ekstrak proyek ini
2. Salin `.env.example` menjadi `.env` dan isi `DATABASE_URL` Postgres Anda
3. Install dep
   ```bash
   npm i
   ```
4. Push schema & generate client
   ```bash
   npm run db:push
   ```
5. Seed data
   ```bash
   npm run db:seed
   ```
6. Jalan
   ```bash
   npm run dev
   ```
   Aplikasi terbuka di http://localhost:3000

## Deploy ke Vercel
- Buat database Postgres (contoh: **Neon** free tier) → copy `DATABASE_URL`
- `vercel init` (atau import repo ke Vercel)
- Set **Environment Variable** `DATABASE_URL` di Project Settings
- Tambah **Build Command**: `npm run build`
- Tambah **Install Command**: `npm ci`
- Tambah **Post-Install Command**: `prisma generate`
- Deploy. Setelah deploy pertama, jalankan **prisma db push** dan **db:seed** memakai **Vercel CLI** atau sementara aktifkan *serverless function* untuk running seed (opsional: jalankan seed secara lokal pada DB yang sama).

## Deploy lewat Docker (opsional)
Contoh `docker-compose.yml`:
```yaml
services:
  db:
    image: postgres:16
    restart: always
    environment:
      POSTGRES_PASSWORD: postgres
      POSTGRES_USER: postgres
      POSTGRES_DB: audit
    ports: ["5432:5432"]
  web:
    build: .
    environment:
      DATABASE_URL: postgresql://postgres:postgres@db:5432/audit?schema=public
    ports: ["3000:3000"]
    depends_on: [db]
```
Lalu:
```bash
docker compose up -d
npm run db:push && npm run db:seed
```

## Struktur Penting
- `src/app/*` → halaman dan API Route
- `prisma/schema.prisma` → schema DB (Prisma)
- `prisma/seed.ts` → data contoh
- `src/components/*` → komponen UI

## Kustomisasi
- Tema Tailwind ada di `tailwind.config.ts` dan `globals.css`
- Tambahkan autentikasi (NextAuth) jika diperlukan
- Lengkapi fitur Import/Export sesuai kebutuhan

---

By: ChatGPT (GPT-5 Thinking)
